function showAddOptions() {
    document.getElementById('main-buttons').classList.add('hidden');
    document.getElementById('add-buttons').classList.remove('hidden');
    document.getElementById('update-buttons').classList.add('hidden');
}

function showUpdateOptions() {
    document.getElementById('main-buttons').classList.add('hidden');
    document.getElementById('add-buttons').classList.add('hidden');
    document.getElementById('update-buttons').classList.remove('hidden');
}

function showAddCityForm() {
    hideAllForms();
    document.getElementById('add-city-form').classList.remove('hidden');
}

function showAddHostelForm() {
    hideAllForms();
    document.getElementById('add-hostel-form').classList.remove('hidden');
}

function showAddRoomTypeForm() {
    hideAllForms();
    document.getElementById('add-room-type-form').classList.remove('hidden');
}

function showAddRoomForm() {
    hideAllForms();
    document.getElementById('add-room-form').classList.remove('hidden');
}

function showUpdateCityForm() {
    hideAllForms();
    document.getElementById('update-city-form').classList.remove('hidden');
}

function showUpdateHostelForm() {
    hideAllForms();
    document.getElementById('update-hostel-form').classList.remove('hidden');
}

function showUpdateRoomTypeForm() {
    hideAllForms();
    document.getElementById('update-room-type-form').classList.remove('hidden');
}

function showUpdateRoomForm() {
    hideAllForms();
    document.getElementById('update-room-form').classList.remove('hidden');
}

// Helper function to hide all forms
function hideAllForms() {
    document.getElementById('add-city-form').classList.add('hidden');
    document.getElementById('add-hostel-form').classList.add('hidden');
    document.getElementById('add-room-type-form').classList.add('hidden');
    document.getElementById('add-room-form').classList.add('hidden');
    document.getElementById('update-city-form').classList.add('hidden');
    document.getElementById('update-hostel-form').classList.add('hidden');
    document.getElementById('update-room-type-form').classList.add('hidden');
    document.getElementById('update-room-form').classList.add('hidden');
}
