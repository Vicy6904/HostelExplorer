document.getElementById('room_id').addEventListener('change', function() {
    // Get the selected option
    var selectedOption = this.options[this.selectedIndex];

    // Get monthly and yearly prices from the data attributes
    var monthlyPrice = selectedOption.getAttribute('data-monthly-price');
    var yearlyPrice = selectedOption.getAttribute('data-yearly-price');

    // Update the display fields
    document.getElementById('monthly_price_display').textContent = monthlyPrice ? monthlyPrice : '--';
    document.getElementById('yearly_price_display').textContent = yearlyPrice ? yearlyPrice : '--';
});

// Trigger the change event on page load to set initial prices if a room is pre-selected
document.getElementById('room_id').dispatchEvent(new Event('change'));

function validateDates() {
    const checkinInput = document.getElementById('checkin_date').value;
    const checkoutInput = document.getElementById('checkout_date').value;

    // Check if both dates are selected
    if (!checkinInput || !checkoutInput) {
        alert("Please select both check-in and check-out dates.");
        return false; // Prevent form submission
    }

    const checkinDate = new Date(checkinInput);
    const checkoutDate = new Date(checkoutInput);

    // Check if check-in date is in the past
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Set time to midnight for accurate comparison
    if (checkinDate < today) {
        alert("Check-in date cannot be in the past.");
        return false; // Prevent form submission
    }

    // Check if check-out date is later than check-in date
    if (checkoutDate <= checkinDate) {
        alert("Check-out date must be later than Check-in date.");
        return false; // Prevent form submission
    }

    // Check if the stay is within the allowed duration (1 month, 12 months)
    const stayMonths = (checkoutDate.getFullYear() - checkinDate.getFullYear()) * 12 + (checkoutDate.getMonth() - checkinDate.getMonth());
    
    // Check for minimum stay of 1 month
    if (stayMonths < 1) {
        alert("The minimum stay is 1 month.");
        return false; // Prevent form submission
    }
    
    // Check if the stay does not exceed 12 months (1 year)
    if (stayMonths > 12) {
        alert("The maximum stay is 1 year.");
        return false; // Prevent form submission
    }

    return true; // Allow form submission
}

// Attach the validation function to the form submission
document.querySelector('.form-container').addEventListener('submit', function(event) {
    if (!validateDates()) {
        event.preventDefault(); // Prevent form submission if validation fails
    }
});
s