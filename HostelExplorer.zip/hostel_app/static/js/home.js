// Function to flip the card
function flipFlop(image) {
    const cardInner = image.closest('.flip-container').querySelector('.flipper');
    cardInner.classList.add('card-flipflop');
}

// Function to flip back the card
function flipBack(image) {
    const cardInner = image.closest('.flip-container').querySelector('.flipper');
    cardInner.classList.remove('card-flipflop');
}
