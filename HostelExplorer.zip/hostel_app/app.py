from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    send_file,
)
from datetime import datetime
from dateutil.relativedelta import relativedelta
import mysql.connector
import json
import io
import secrets
import calendar

app = Flask(__name__)
app.secret_key = "your_secret_key"

db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "hostel_db",
}

with open("admins.json", "r") as file:
    data = json.load(file)

admin_idp = data["admins"]


def get_db_connection():
    conn = mysql.connector.connect(**db_config)
    return conn


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        conn = get_db_connection()
        cursor = conn.cursor()
        username = request.form["username"]
        password = request.form["password"]

        for admin in admin_idp:
            if admin["username"] == username and admin["password"] == password:
                session["admin"] = True
                return redirect(url_for("admin"))

        cursor.execute(
            "SELECT * FROM users WHERE username=%s AND password=%s",
            (username, password),
        )
        user = cursor.fetchone()
        print(user)
        if user:
            session["user_id"] = user[0]
            session["admin"] = False
            return redirect(url_for("home"))

        return render_template("login.html", error="Invalid username or password")

    return render_template("login.html")


@app.route("/signup", methods=["POST"])
def signup():
    username = request.form["username"]
    email = request.form["email"]
    password = request.form["password"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    existing_user = cursor.fetchone()

    if existing_user:
        flash("Email already registered.", "danger")
        return redirect(url_for("login"))

    cursor.execute(
        "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
        (username, email, password),
    )
    conn.commit()

    conn.close()
    flash("Signup successful! Please log in.", "success")
    return redirect(url_for("login"))


@app.route("/home")
def home():
    if "user_id" not in session or session.get("admin"):
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT id, name FROM cities")
    cities = cursor.fetchall()

    cursor.execute(
        """
        SELECT id, name, near_college, rating, city_id, description
        FROM hostels
    """
    )
    hostels = cursor.fetchall()

    cursor.execute("SELECT * FROM room_types")
    room_types = cursor.fetchall()

    conn.close()

    return render_template(
        "home.html", cities=cities, hostels=hostels, room_types=room_types
    )


@app.route("/food_image/<int:image_id>")
def get_image(image_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT image FROM hostels WHERE id = %s", (image_id,))
    image_data = cursor.fetchone()

    if image_data is None:

        return "No image found"

    return send_file(
        io.BytesIO(image_data[0]),
        mimetype="image/jpeg",
        as_attachment=False,
        download_name=f"image_{image_id}.jpg",
    )


@app.route("/city/<int:city_id>")
def city_hostels(city_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT id, name FROM cities WHERE id = %s", (city_id,))
    city = cursor.fetchone()

    cursor.execute(
        """
        SELECT h.id, h.name, h.near_college, h.rating, h.image, h.description
        FROM hostels h
        WHERE h.city_id = %s
    """,
        (city_id,),
    )
    hostels = cursor.fetchall()

    conn.close()

    return render_template("home.html", city=city, hostels=hostels)


@app.route("/admin")
def admin():
    if not session.get("admin"):
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT id, username, email, created_at FROM users")
    users = cursor.fetchall()

    cursor.execute(
        """
        SELECT h.id, h.name, h.near_college, h.rating, c.name AS city_name, h.description 
        FROM hostels h
        JOIN cities c ON h.city_id = c.id
    """
    )
    hostels = cursor.fetchall()

    cursor.execute("SELECT id, name FROM cities")
    cities = cursor.fetchall()

    cursor.execute("SELECT id, name FROM room_types")
    room_types = cursor.fetchall()

    cursor.execute(
        """
        SELECT 
            r.id AS id,
            h.id AS hostel_id, 
            h.name AS hostel_name, 
            rt.id AS room_type_id, 
            rt.name AS room_type_name, 
            r.hostel_id, 
            r.room_type_id, 
            r.room_count, 
            r.monthly_price, 
            r.yearly_price, 
            r.availability, 
            r.isavailability
        FROM 
            hostels h
        JOIN 
            rooms r ON h.id = r.hostel_id
        JOIN 
            room_types rt ON r.room_type_id = rt.id
        """
    )
    rooms = cursor.fetchall()
    try:
        if rooms[0]["isavailability"] == 1:
            room_availability = "Available"
        else:
            room_availability = "Unavailable"
    except:
        room_availability = "NOT FOUND"

    cursor.execute(
        """
        SELECT 
            b.id, 
            b.user_id, 
            b.room_id, 
            b.checkin_date, 
            b.is_checkin, 
            b.checkout_date, 
            b.is_checkout, 
            b.unique_code, 
            b.status, 
            u.username, 
            r.hostel_id, 
            r.room_type_id, 
            r.room_count, 
            r.monthly_price, 
            r.yearly_price
        FROM 
            bookings b
        JOIN 
            users u ON b.user_id = u.id
        JOIN 
            rooms r ON b.room_id = r.id
        """
    )
    bookings = cursor.fetchall()

    conn.close()

    return render_template(
        "admin.html",
        users=users,
        hostels=hostels,
        cities=cities,
        room_types=room_types,
        rooms=rooms,
        room_availability=room_availability,
        bookings=bookings,
    )


@app.route("/configuration")
def configuration():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT id, name FROM cities")
    cities = cursor.fetchall()

    cursor.execute("SELECT id, name FROM hostels")
    hostels = cursor.fetchall()

    cursor.execute("SELECT id, name FROM room_types")
    room_types = cursor.fetchall()

    conn.close()

    return render_template(
        "configuration.html", cities=cities, hostels=hostels, room_types=room_types
    )


@app.route("/add_city", methods=["POST"])
def add_city():
    name = request.form["name"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("INSERT INTO cities (name) VALUES (%s)", (name,))
    conn.commit()
    conn.close()

    flash("City added successfully!", "success")
    return redirect(url_for("configuration"))


@app.route("/add_hostel", methods=["POST"])
def add_hostel():
    name = request.form["name"]
    near_college = request.form["near_college"]
    rating = request.form["rating"]
    city_id = request.form["city_id"]
    image = request.files["image"].read()
    description = request.form["description"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO hostels (name, near_college, rating, city_id, image, description)
        VALUES (%s, %s, %s, %s, %s, %s)
    """,
        (name, near_college, rating, city_id, image, description),
    )
    conn.commit()
    conn.close()

    flash("Hostel added successfully!", "success")
    return redirect(url_for("configuration"))


@app.route("/update_city", methods=["POST"])
def update_city():
    old_name = request.form["old_name"]
    new_name = request.form["new_name"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE cities SET name = %s WHERE name = %s", (new_name, old_name))
    conn.commit()
    conn.close()

    flash("City updated successfully!", "success")
    return redirect(url_for("configuration"))


@app.route("/update_hostel", methods=["POST"])
def update_hostel():
    old_name = request.form["old_name"]
    new_name = request.form["new_name"]
    new_near_college = request.form["new_near_college"]
    new_rating = request.form["new_rating"]
    city_id = request.form["city_id"]

    print(old_name, new_name, new_near_college, new_rating, city_id)
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE hostels 
        SET name = %s, near_college = %s, rating = %s, city_id = %s 
        WHERE id = %s
    """,
        (new_name, new_near_college, new_rating, city_id, old_name),
    )
    conn.commit()
    conn.close()

    flash("Hostel updated successfully!", "success")
    return redirect(url_for("configuration"))


@app.route("/add_room_type", methods=["POST"])
def add_room_type():
    name = request.form["name"]
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO room_types(name) VALUES (%s)", (name,))
    conn.commit()
    conn.close()
    return redirect(url_for("configuration"))


@app.route("/add_room", methods=["POST"])
def add_room():
    hostel_id = request.form["hostel_id"]
    room_type_id = request.form["room_type_id"]
    room_count = request.form["room_count"]
    monthly_price = request.form["monthly_price"]
    yearly_price = request.form["yearly_price"]
    availability = request.form["room_count"]

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO rooms(hostel_id, room_type_id, room_count, monthly_price, yearly_price, availability) VALUES (%s,%s,%s,%s,%s, %s)",
        (
            hostel_id,
            room_type_id,
            room_count,
            monthly_price,
            yearly_price,
            availability,
        ),
    )
    conn.commit()
    conn.close()

    return redirect(url_for("configuration"))


@app.route("/update_room_type", methods=["POST"])
def update_room_type():
    room_type_id = request.form["room_type_id"]
    new_name = request.form["new_name"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE room_types SET name = %s WHERE id = %s", (new_name, room_type_id)
    )
    conn.commit()
    conn.close()

    flash("Room type updated successfully!", "success")
    return redirect(url_for("configuration"))


@app.route("/update_room", methods=["POST"])
def update_room():
    room_id = request.form["room_id"]
    new_room_count = request.form["new_room_count"]
    new_monthly_price = request.form["new_monthly_price"]
    new_yearly_price = request.form["new_yearly_price"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE rooms 
        SET room_count = %s, monthly_price = %s, yearly_price = %s 
        WHERE id = %s
    """,
        (new_room_count, new_monthly_price, new_yearly_price, room_id),
    )
    conn.commit()
    conn.close()

    flash("Room updated successfully!", "success")
    return redirect(url_for("configuration"))


@app.route("/bookings", methods=["GET", "POST"])
def bookings():
    if "user_id" not in session:
        return redirect(url_for("login"))

    hostel_id = request.args.get("hostel_id")  # Get the hostel ID from the URL

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch only rooms from the selected hostel that have availability
    if hostel_id:
        cursor.execute(
            """
            SELECT r.id, r.availability, r.monthly_price, r.yearly_price, rt.name AS room_type_name, h.name AS hostel_name
            FROM rooms r
            JOIN room_types rt ON r.room_type_id = rt.id
            JOIN hostels h ON r.hostel_id = h.id
            WHERE r.availability > 0 AND r.hostel_id = %s
            """,
            (hostel_id,),
        )
    else:
        # Fallback in case no hostel ID is provided
        cursor.execute(
            """
            SELECT r.id, r.availability, r.monthly_price, r.yearly_price, rt.name AS room_type_name, h.name AS hostel_name
            FROM rooms r
            JOIN room_types rt ON r.room_type_id = rt.id
            JOIN hostels h ON r.hostel_id = h.id
            WHERE r.availability > 0
            """
        )

    rooms = cursor.fetchall()
    conn.close()

    return render_template("bookings.html", rooms=rooms, section=True)


@app.route("/confirm_booking", methods=["POST"])
def confirm_booking():
    uniquecode = request.form["uniquecode"]
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE bookings
        SET status = 'confirmed'
        WHERE unique_code = %s
    """,
        (uniquecode,),
    )

    conn.commit()
    conn.close()

    return redirect(url_for("admin"))


@app.route("/add_booking", methods=["POST"])
def add_booking():
    user_id = session.get("user_id")
    room_id = request.form["room_id"]
    checkin_date = request.form["checkin_date"]
    checkout_date = request.form["checkout_date"]

    conn = get_db_connection()
    cursor = conn.cursor()

    # Fetch the room's pricing (monthly and yearly)
    cursor.execute(
        "SELECT monthly_price, yearly_price FROM rooms WHERE id = %s", (room_id,)
    )
    checkin = datetime.strptime(checkin_date, '%Y-%m-%d')
    checkout = datetime.strptime(checkout_date, '%Y-%m-%d')

    # Calculate the difference in years and months
    year_diff = checkout.year - checkin.year
    month_diff = checkout.month - checkin.month

    # Calculate the total months difference
    total_months = year_diff * 12 + month_diff
    if total_months == 0:
        total_months = 1

    room_prices = cursor.fetchone()
    monthly_price = room_prices[0]
    yearly_price = room_prices[1]
    print(total_months)
    # Determine the price based on the booking duration
    if total_months >= 12:
        price = yearly_price

    else:
        price = total_months * monthly_price

    unique_code = secrets.token_urlsafe(7)

    # Insert booking with calculated price
    cursor.execute(
        """
        INSERT INTO bookings 
        (user_id, room_id, checkin_date, checkout_date, price, unique_code, status) 
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """,
        (
            user_id,
            room_id,
            checkin_date,
            checkout_date,
            price,
            unique_code,
            "Unconfirm",
        ),
    )

    # Update room availability if necessary
    cursor.execute(
        "UPDATE rooms SET isavailability = FALSE WHERE availability = 0 AND id = %s",
        (room_id,),
    )

    conn.commit()
    conn.close()

    flash("Booking successful!", "success")
    return render_template("bookings.html", section=False, unique_code=unique_code)



@app.route("/checkin", methods=["POST"])
def checkin():
    booking_id = request.form["booking_id"]
    room_id = request.form["room_id"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE rooms SET availability = availability - 1 WHERE id = %s", (room_id,)
    )
    conn.commit()
    cursor.execute(
        "UPDATE rooms SET isavailability = FALSE WHERE availability = 0 AND id = %s",
        (room_id,),
    )
    conn.commit()

    cursor.execute("UPDATE bookings SET is_checkin = 1 WHERE id = %s ", (booking_id,))
    conn.commit()

    conn.commit()
    conn.close()

    flash("Checked in successfully!", "success")
    return redirect(url_for("admin"))


@app.route("/checkout", methods=["POST"])
def checkout():
    booking_id = request.form["booking_id"]
    room_id = request.form["room_id"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE rooms SET availability = availability + 1 WHERE id = %s", (room_id,)
    )
    conn.commit()
    cursor.execute(
        "UPDATE rooms SET isavailability = TRUE WHERE availability > 0 AND id = %s",
        (room_id,),
    )
    conn.commit()

    cursor.execute("UPDATE bookings SET is_checkout = 1 WHERE id = %s ", (booking_id,))
    conn.commit()

    conn.commit()
    conn.close()

    flash("Checked out successfully!", "success")
    return redirect(url_for("admin"))


@app.route("/booking", methods=["POST"])
def booking_status():
    uniquecode = request.form["uniquecode"]
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT 
                users.username AS user_name,
                bookings.unique_code,
                hostels.name AS hostel_name,
                bookings.price,
                room_types.name AS room_type_name,
                bookings.checkin_date,
                bookings.checkout_date,
                bookings.created_at AS created_date,
                bookings.status
            FROM 
                bookings
            JOIN users ON bookings.user_id = users.id
            JOIN rooms ON bookings.room_id = rooms.id
            JOIN hostels ON rooms.hostel_id = hostels.id
            JOIN room_types ON rooms.room_type_id = room_types.id
            WHERE 
                bookings.unique_code = %s;
            """,
            (uniquecode,),
        )

        booking_data = cursor.fetchall()[0]
        conn.close()
        return render_template("user_info_card.html", booking_data=booking_data)
    except:
        return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
